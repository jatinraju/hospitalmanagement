package com.hms.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int pid;
	private String name;
	private int age;
	private int room;
	private String doctor_name;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "UTC")
	private LocalDate admit_date;

	private double expenses;
	private String status;

	public Patient() {
		super();
	}

	public Patient(String name, int age, int room, String doctor_name, LocalDate admit_date, double expenses,
			String status) {
		super();
		this.name = name;
		this.age = age;
		this.room = room;
		this.doctor_name = doctor_name;
		this.admit_date = admit_date;
		this.expenses = expenses;
		this.status = status;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getRoom() {
		return room;
	}

	public void setRoom(int room) {
		this.room = room;
	}

	public String getDoctor_name() {
		return doctor_name;
	}

	public void setDoctor_name(String doctor_name) {
		this.doctor_name = doctor_name;
	}

	public LocalDate getAdmit_date() {
		return admit_date;
	}

	public void setAdmit_date(LocalDate admit_date) {
		this.admit_date = admit_date;
	}

	public double getExpenses() {
		return expenses;
	}

	public void setExpenses(double expenses) {
		this.expenses = expenses;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Patient [pid=" + pid + ", name=" + name + ", age=" + age + ", room=" + room + ", doctor_name="
				+ doctor_name + ", admit_date=" + admit_date + ", expenses=" + expenses + ", status=" + status + "]";
	}

}
