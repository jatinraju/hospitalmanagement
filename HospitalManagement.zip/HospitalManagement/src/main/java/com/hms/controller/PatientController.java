package com.hms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hms.exception.InvalidInputValueException;
import com.hms.exception.NoDataFoundException;
import com.hms.model.Patient;
import com.hms.service.PatientService;

@Controller
@RequestMapping("/admin")
public class PatientController {

	@Autowired
	private PatientService pservice;

	// just an example
	@GetMapping("/home")
	@ResponseBody
	public String getHome() {
		return "Demo: This is Admin Home Page";
	}

	// Adding Patient
	@PostMapping("/add")
	public ResponseEntity<?> addPatient(@RequestBody Patient patient) throws InvalidInputValueException {

		Patient resultPatient = pservice.addPatient(patient);
		if (resultPatient == null) {
			throw new InvalidInputValueException("There must be invalid or missing input.");
		}
		return new ResponseEntity<>(resultPatient, HttpStatus.CREATED);

	}

	// Getting the list of admitted patient
	@GetMapping("/getAll")
	public ResponseEntity<?> getAllPatients() throws NoDataFoundException {
		List<Patient> patientList = pservice.getAllPatients();
		if (patientList.isEmpty()) {
			// throw new NoDataFoundException("No Data Found!");
			return new ResponseEntity<>(patientList, HttpStatus.OK);
		}
		return new ResponseEntity<>(patientList, HttpStatus.OK);
	}

	// Discharge Patient
	@PutMapping("/discharge")
	public ResponseEntity<?> dischargePatient(@RequestBody Patient patient) throws InvalidInputValueException {
		Patient resultPatient = pservice.dischargePatient(patient);
		if (resultPatient == null) {
			throw new InvalidInputValueException("There must be invalid or missing input.");
		}
		return new ResponseEntity<>(resultPatient, HttpStatus.OK);
		// return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	}

}
