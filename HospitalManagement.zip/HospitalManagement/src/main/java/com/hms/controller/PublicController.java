package com.hms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hms.exception.UserReleatedException;
import com.hms.model.User;
import com.hms.service.CustomUserDetailService;

@Controller
@RequestMapping("/public")
public class PublicController {

	@Autowired
	private CustomUserDetailService customUserDetailService;

	@PostMapping("/signup")
	@ResponseBody
	public User getSignup(@RequestBody User user) throws UserReleatedException {
		User resultUser = customUserDetailService.addUser(user);
		if (resultUser == null) {
			throw new UserReleatedException("User ID should be unique & length for id password > 6");
		}
		return user;
	}
}
