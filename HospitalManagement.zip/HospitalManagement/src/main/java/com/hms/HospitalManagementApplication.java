package com.hms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.hms.model.User;
import com.hms.repo.UserRepo;

@SpringBootApplication
public class HospitalManagementApplication implements CommandLineRunner {
	@Autowired
	private UserRepo urepo;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	public static void main(String[] args) {
		SpringApplication.run(HospitalManagementApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		User user = new User();
		user.setId("jatin");
		user.setPassword(this.bCryptPasswordEncoder.encode("raju"));
		user.setRole("ROLE_ADMIN");
		urepo.save(user);
	}

}
