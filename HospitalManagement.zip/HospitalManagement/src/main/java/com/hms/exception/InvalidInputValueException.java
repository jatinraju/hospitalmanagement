package com.hms.exception;

public class InvalidInputValueException extends Exception {
	private static final long serialVersionUID = 1L;
	String message;

	public InvalidInputValueException(String message) {
		super(message);
	}
}
