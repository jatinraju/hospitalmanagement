package com.hms.exception;

public class UserReleatedException extends Exception {

	private static final long serialVersionUID = 1L;
	String message;

	public UserReleatedException(String message) {
		super(message);
	}
}
