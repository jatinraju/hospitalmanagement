package com.hms.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.model.Patient;
import com.hms.repo.PatientRepo;

@Service
public class PatientServiceImpl implements PatientService {

	@Autowired
	private PatientRepo prepo;

	// String Validation
	@Override
	public boolean isValidName(String name) {

		CharSequence inputStr = name;
		Pattern pattern = Pattern.compile(new String("^[a-zA-Z\\s]*$"));
		Matcher matcher = pattern.matcher(inputStr);
		if (matcher.matches()) {
			return true;
		} else {
			return false;
		}
	}

	// Status Validation
	@Override
	public boolean isValidStatus(String status) {
		if (status.equalsIgnoreCase("admitted") || status.equalsIgnoreCase("discharge")) {
			return true;
		}
		return false;
	}

	// Date Validation
	@Override
	public boolean isValidDateFormat(LocalDate dateString) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
			String formattedDate = dateString.format(formatter);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	// Validation
	@Override
	public boolean checkGivenInput(Patient patient) {
		if (patient.getName() == "" || patient.getName() == null || patient.getAge() <= 0 || patient.getRoom() <= 0
				|| patient.getDoctor_name() == "" || patient.getDoctor_name() == null || patient.getExpenses() <= 0
				|| patient.getStatus() == "" || patient.getStatus() == null) {
			return false;
		}
		if (!isValidName(patient.getName()) || !isValidName(patient.getDoctor_name())) {
			return false;
		}
		if (!isValidStatus(patient.getStatus())) {
			return false;
		}
		if (!isValidDateFormat(patient.getAdmit_date())) {
			return false;
		}
		return true;
	}

	@Override
	public Patient addPatient(Patient patient) {
		if (checkGivenInput(patient)) {
			prepo.save(patient);
			return patient;
		}
		return null;
	}

	@Override
	public List<Patient> getAllPatients() {
		return prepo.findByStatus("admitted");
	}

	@Override
	public Patient dischargePatient(Patient patient) {
		if (isValidStatus(patient.getStatus())) {
			Optional<Patient> opt = prepo.findById(patient.getPid());
			Patient p = opt.get();
			if (p == null) {
				return null;
			}
			p.setStatus(patient.getStatus());
			prepo.save(p);
			return p;
		}
		return null;
	}

}
