package com.hms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.hms.model.CustomUserDetail;
import com.hms.model.User;
import com.hms.repo.UserRepo;

@Service
public class CustomUserDetailService implements UserDetailsService {

	@Autowired
	private UserRepo uRepo;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// Fetching user from database
		User user = uRepo.findById(username);
		if (user == null) {
			throw new UsernameNotFoundException("User not found !!!");
		}
		CustomUserDetail customUserDetails = new CustomUserDetail(user);
		return customUserDetails;
	}

	public boolean isValidUser(User user) {
		if (user.getId().trim().length() <= 6 && user.getPassword().trim().length() <= 6)
			return false;
		return true;
	}

	public User addUser(User user) {
		User checkUser = uRepo.findById(user.getId());
		if (isValidUser(user)) {
			if (checkUser == null) {
				user.setPassword(this.bCryptPasswordEncoder.encode(user.getPassword()));
				user.setRole("ROLE_ADMIN");
				uRepo.save(user);
				return user;
			}
		}
		return null;

	}
}
