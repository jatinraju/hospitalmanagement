package com.hms.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.hms.model.Patient;

@Service
public interface PatientService {
	public Patient addPatient(Patient patient);

	public List<Patient> getAllPatients();

	public Patient dischargePatient(Patient patient);

	public boolean checkGivenInput(Patient patient);

	public boolean isValidName(String name);

	public boolean isValidStatus(String status);

	public boolean isValidDateFormat(LocalDate dateString);

}
